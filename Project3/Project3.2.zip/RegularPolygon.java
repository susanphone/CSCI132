// CSCI 132 - Project 2
// Susan McCartney
// July 13, 2020

package Project3;

public interface RegularPolygon {

    // Methods
    public double perimeter();

    public double area();
}
